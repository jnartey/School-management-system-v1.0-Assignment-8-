package CoreJava.Models;

public class Student {

    public void setEmail(String email){

    }

    public String getEmail(){

    }

    public void setName(String name){

    }

    public String getName(){

    }

    public void setPass(String pass){

    }

    public String getPass(){

    }
}
