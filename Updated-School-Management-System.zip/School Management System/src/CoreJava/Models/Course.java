package CoreJava.Models;

public class Course {

    public void setID(int ID){

    }

    public int getID(){

    }

    public void setName(String name){

    }

    public String getName(){

    }

    public void setInstructor(String instructor){

    }

    public String getInstructor(){

    }

}
