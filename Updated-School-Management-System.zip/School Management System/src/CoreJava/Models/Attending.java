package CoreJava.Models;

public class Attending {

    public void setCourseID(int courseID){

    }

    public int getCourseID(){

    }

    public void setStudentEmail(String studentEmail){

    }

    public String getStudentEmail(){

    }
}
