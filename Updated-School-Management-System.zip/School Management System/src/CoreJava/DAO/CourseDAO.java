package CoreJava.DAO;

import CoreJava.Models.Course;

import java.util.List;

public class CourseDAO {
    public List<Course> getAllCourses(){

    }
}
