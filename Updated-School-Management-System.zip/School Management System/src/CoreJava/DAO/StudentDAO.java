package CoreJava.DAO;

import CoreJava.Models.Student;

import java.util.List;

public class StudentDAO {
    public List<Student>  getStudents(){

    }

    public Student getStudentByEmail(List<Student> studentList, String studentEmail){

    }

    public boolean validateUser(List<Student> studentList, String studentEmail, String studentPass){

    }
}
