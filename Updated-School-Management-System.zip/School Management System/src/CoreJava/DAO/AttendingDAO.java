package CoreJava.DAO;

import CoreJava.Models.Attending;
import CoreJava.Models.Course;

import java.util.List;

public class AttendingDAO {

    public List<Attending> getAttending(){

    }

    public void registerStudentToCourse(List<Attending> attending, String studentEmail, int courseID){

    }

    public List<Course> getStudentCourses(List<Course> courseList, List<Attending> attending, String studentEmail){

    }

    public void saveAttending(List<Attending> attending){

    }

}
